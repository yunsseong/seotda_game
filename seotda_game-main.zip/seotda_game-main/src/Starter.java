public class Starter {
    public static void main(String[] args) {
        Dealer d = new Dealer();
        new SeotdaController(d).manageSeotda();
    }
}
